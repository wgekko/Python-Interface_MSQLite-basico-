#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Dec 16 21:10:44 2021

@author: walter
"""

## ejercicio de BBDD  con mqlite
## haciendo CRUD
#
import sqlite3
from tkinter import messagebox

# ------------ funcion para crear la base de datos -------------------------

def conexionBBDD():
    miConexion=sqlite3.connect("Usuario")
    miCursor=miConexion.cursor()
    try:
        miCursor.execute('''CREATE TABLE USUARIO (ID INTEGER PRIMARY KEY AUTOINCREMENT, NOMBRE VARCHAR(50),
                                                APELLIDO VARCHAR(50), DIRECCION VARCHAR(60), MAIL VARCHAR(50) UNIQUE,
                                                CLAVE VARCHAR(10), COMENTARIO VARCHAR(300))''')
        
        messagebox.showinfo("Crear BBDD", "Base de datos creada con éxito")
        
    except:
        messagebox.showwarning("¡¡¡ Atención !!!", "la base de datos ya existe")                

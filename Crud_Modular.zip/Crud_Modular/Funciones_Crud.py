#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Dec 18 01:16:11 2021

@author: walter
"""

from tkinter import *
from tkinter import messagebox
import sqlite3

# ------------------ funciones para realizar el crud -------------------------------------------------



def salir():
    valor=messagebox.askquestion("Salir","¿ Desea salir de la aplicación...?")
    if valor=="yes":
        root.destroy()
        

def limpiarCampos():
    
    miId.set("")
    miNombre.set("")   
    miApellido.set("")
    miDireccion.set("")
    miMail.set("")
    miClave.set("")
    textoComentario.delete(1.0,END)
    
    
def crear():
     miConexion=sqlite3.connect("Usuario")
     miCursor=miConexion.cursor()
     # otra opciones de query
     # datos=miNombre.get(),miApellido.get(),miDireccion.get(),miMail.get(), miClave.get(),textoComentario.get("1.0", END) 
     # miCursor.execute("INSERT INTO DATOUSUARIO VALUES (NULL, ?,?,?,?,?,?,?)",(datos))
     
     miCursor.execute("INSERT INTO DATOUSUARIO VALUES ( NULL, '" + miNombre.get() + 
                                                     "','" + miApellido.get() + 
                                                     "','" + miDireccion.get() +
                                                     "','" + miMail.get() +
                                                     "','" + miClave.get() + 
                                                     "','" + textoComentario.get("1.0", END) + "')")   
     
     miConexion.commit()
     
     messagebox.showinfo("Crear", "Registro creado con éxito...")
    
def leer():
     miConexion=sqlite3.connect("Usuario")
     miCursor=miConexion.cursor()
     miCursor.execute("SELECT * FROM DATOUSUARIO WHERE ID=" + miId.get())   
     
     elUsuario=miCursor.fetchall()
     for usuario in elUsuario:
         miId.set(usuario[0])
         miNombre.set(usuario[1])
         miApellido.set(usuario[2])
         miDireccion.set(usuario[3])
         miMail.set(usuario[4])
         miClave.set(usuario[5])
         textoComentario.insert(1.0, usuario[6])        
         
     miConexion.commit()
     
def editar():
     miConexion=sqlite3.connect("Usuario")
     miCursor=miConexion.cursor()
     # otra opciones de query
     # datos=miNombre.get(),miApellido.get(),miDireccion.get(),miMail.get(), miClave.get(),textoComentario.get("1.0", END) 
     # miCursor.execute("UPDATE DATOUSUARIO SET NOMBRE=?, APELLLIDO=?, DIRECCION=?, MAIL=?, CLAVE=?, COMENTARIO=? " + "WHERE ID=" +miId.get(),(datos)) 
     
     miCursor.execute("UPDATE DATOUSUARIO SET NOMBRE='" + miNombre.get() + 
                                                     "', APELLIDO='" + miApellido.get() + 
                                                     "', DIRECCION='" + miDireccion.get() +
                                                     "', MAIL='" + miMail.get() +
                                                     "', CLAVE='" + miClave.get() + 
                                                     "', COMENTARIO='" + textoComentario.get("1.0", END) +
                                                     "' WHERE ID=" + miId.get())   
     
     miConexion.commit()
     
     messagebox.showinfo("Editar", "Registro se ha actualizado con  éxito...")
     

def borrar():
     miConexion=sqlite3.connect("Usuario")
     miCursor=miConexion.cursor()
     miCursor.execute("DELETE FROM DATOUSUARIO WHERE ID=" + miId.get())   
     
     miConexion.commit()
     
     messagebox.showinfo("Borrar", "Registro se ha borrado con  éxito...")
     

     
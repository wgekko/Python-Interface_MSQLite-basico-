#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Dec 18 01:18:24 2021

@author: walter
"""

# -------------------funciones de Descripcion --------------------------------------


def licencia():

    messagebox.showinfo("Licencia de Walter Gómez", "A modo de desarrollo de un ejercicio en Python con BBDD,"
                                                          "\n\n"   
                                                         " usando MSQLite"
                                                         "\n\n"                                                         
                                                         " se busca practica en el desarrollo "
                                                          "\n\n"
                                                         "de herramientas de lenguaje Python.")
    
def proyecto():

    messagebox.showinfo("Proyecto CRUD en Python ", "Gestor de Usuarios , es un pequeño proyecto que busca utilizar,"
                                                         "\n\n"                          
                                                         " las herramientas clasicas de crear, leer, actualizar, borrar, "
                                                         "\n\n"   
                                                         " la base de datos usadas es MSQLite, apta para este caso para no  "
                                                         "\n\n"
                                                         " consumir tantos recursos y a modo de practivca de adminitración"
                                                         "\n\n"    
                                                         " de archivos y registros.")
                                                   
